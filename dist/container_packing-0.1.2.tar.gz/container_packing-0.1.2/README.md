# 3d-bin-container-packing
A variant of the Largest Area Fit First (LAFF) algorithm

This library is imlementation of [this library](https://github.com/skjolber/3d-bin-container-packing) using python.
